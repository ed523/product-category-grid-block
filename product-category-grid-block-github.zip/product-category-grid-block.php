<?php
/**
 * Plugin Name: Product Category Grid Block
 * Description: Displays WooCommerce product categories in a responsive grid with image, title, and alignment options.
 * Version: 1.2
 * Author: Ed Reibsamen
 */

defined('ABSPATH') || exit;

function pcg_register_block() {
    wp_register_script(
        'pcg-block-script',
        plugins_url('block.js', __FILE__),
        [ 'wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n', 'wp-block-editor' ],
        filemtime(plugin_dir_path(__FILE__) . 'block.js'),
        true
    );

    register_block_type('pcg/category-grid', [
        'editor_script'   => 'pcg-block-script',
        'render_callback' => 'pcg_render_callback',
        'attributes'      => [
            'parentCat'      => [ 'type' => 'number',  'default' => 0 ],
            'hideEmpty'      => [ 'type' => 'boolean', 'default' => true ],
            'columnsDesktop' => [ 'type' => 'number',  'default' => 3 ],
            'columnsTablet'  => [ 'type' => 'number',  'default' => 2 ],
            'columnsMobile'  => [ 'type' => 'number',  'default' => 1 ],
            'align'          => [ 'type' => 'string',  'default' => '' ],
        ],
    ]);
}
add_action('init', 'pcg_register_block');

function pcg_get_product_thumb_from_cat($cat_id) {
    $q = new WP_Query([
        'post_type'      => 'product',
        'posts_per_page' => 1,
        'tax_query'      => [[
            'taxonomy' => 'product_cat',
            'field'    => 'term_id',
            'terms'    => $cat_id,
        ]],
        'meta_query'     => [[
            'key'     => '_thumbnail_id',
            'compare' => 'EXISTS',
        ]],
        'fields'         => 'ids',
        'no_found_rows'  => true,
    ]);

    if (empty($q->posts)) return '';
    $thumb_id = get_post_thumbnail_id($q->posts[0]);
    return $thumb_id ? wp_get_attachment_url($thumb_id) : '';
}

function pcg_render_callback($attributes) {
    if (!function_exists('get_woocommerce_term_meta')) return '';

    $parent     = $attributes['parentCat']      ?? 0;
    $hide_empty = $attributes['hideEmpty']      ?? true;
    $cols_d     = $attributes['columnsDesktop'] ?? 3;
    $cols_t     = $attributes['columnsTablet']  ?? 2;
    $cols_m     = $attributes['columnsMobile']  ?? 1;
    $align      = $attributes['align']          ?? '';

    $terms = get_terms([
        'taxonomy'   => 'product_cat',
        'hide_empty' => $hide_empty,
        'parent'     => $parent,
    ]);

    if (empty($terms) || is_wp_error($terms)) return '';

    $style_props = sprintf('style="--pcg-cols-d:%d;--pcg-cols-t:%d;--pcg-cols-m:%d;"',
        $cols_d, $cols_t, $cols_m);

    $align_class = $align ? 'align' . esc_attr($align) : '';
    $output = '<div class="pcg-grid ' . $align_class . '" ' . $style_props . '>';

    foreach ($terms as $term) {
        $thumb_id  = get_term_meta($term->term_id, 'thumbnail_id', true);
        $image_url = wp_get_attachment_url($thumb_id);
        if (!$image_url) {
            $image_url = pcg_get_product_thumb_from_cat($term->term_id);
        }
        $link = get_term_link($term);
        $output .= '<div class="pcg-item">';
        if ($image_url) {
            $output .= '<a href="' . esc_url($link) . '"><img src="' . esc_url($image_url) . '" alt="' . esc_attr($term->name) . '"></a>';
        }
        $output .= '<h3><a href="' . esc_url($link) . '">' . esc_html($term->name) . '</a></h3>';
        $output .= '</div>';
    }

    $output .= '</div>';
    return $output;
}

function pcg_enqueue_styles() {
    wp_enqueue_style('pcg-styles', plugins_url('style.css', __FILE__), [], filemtime(plugin_dir_path(__FILE__) . 'style.css'));
}
add_action('wp_enqueue_scripts', 'pcg_enqueue_styles');
