# Product Category Grid Block

A lightweight, responsive WordPress block that displays WooCommerce product categories in a customizable grid.

## Features

- Grid of WooCommerce product categories (with thumbnails)
- Fallback to a product image if the category has none
- Responsive column settings (desktop, tablet, mobile)
- Optional wide/full alignment in block themes
- No frontend JavaScript, minimal dependencies

## How to Use

1. Upload as a plugin to your WordPress site.
2. Activate it.
3. Add the “Product Category Grid” block in any post or page.
4. Configure settings in the block sidebar.

## Future Ideas

- Sort order and custom ordering
- Show category descriptions
- Filter by tags or custom taxonomies
- Built-in lazy loading

🛠 Created by Ed Reibsamen. Inspired by the Ghetto Lot shop needs.
