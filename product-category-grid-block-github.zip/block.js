const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const { InspectorControls } = wp.blockEditor || wp.editor;
const { PanelBody, TextControl, ToggleControl, SelectControl } = wp.components;
const { Fragment, createElement: el } = wp.element;

registerBlockType('pcg/category-grid', {
    title: __('Product Category Grid', 'pcg'),
    icon: 'grid-view',
    category: 'widgets',

    attributes: {
        parentCat: { type: 'number',  default: 0 },
        hideEmpty: { type: 'boolean', default: true },
        columnsDesktop: { type: 'number',  default: 3 },
        columnsTablet:  { type: 'number',  default: 2 },
        columnsMobile:  { type: 'number',  default: 1 },
        align:          { type: 'string',  default: '' },
    },

    edit({ attributes, setAttributes }) {
        return el(Fragment, {},
            el(InspectorControls, {},
                el(PanelBody, { title: __('Grid Settings', 'pcg'), initialOpen: true },
                    el(TextControl, {
                        label: __('Parent Category ID (0 = top-level)', 'pcg'),
                        type: 'number',
                        value: attributes.parentCat ?? 0,
                        onChange: (val) => setAttributes({ parentCat: parseInt(val || 0, 10) })
                    }),
                    el(ToggleControl, {
                        label: __('Hide Empty Categories', 'pcg'),
                        checked: attributes.hideEmpty ?? true,
                        onChange: (val) => setAttributes({ hideEmpty: val })
                    }),
                    el(TextControl, {
                        label: __('Columns (Desktop)', 'pcg'),
                        type: 'number',
                        value: attributes.columnsDesktop ?? 3,
                        onChange: val => setAttributes({ columnsDesktop: parseInt(val || 3, 10) })
                    }),
                    el(TextControl, {
                        label: __('Columns (Tablet)', 'pcg'),
                        type: 'number',
                        value: attributes.columnsTablet ?? 2,
                        onChange: val => setAttributes({ columnsTablet: parseInt(val || 2, 10) })
                    }),
                    el(TextControl, {
                        label: __('Columns (Mobile)', 'pcg'),
                        type: 'number',
                        value: attributes.columnsMobile ?? 1,
                        onChange: val => setAttributes({ columnsMobile: parseInt(val || 1, 10) })
                    }),
                    el(SelectControl, {
                        label: __('Align', 'pcg'),
                        value: attributes.align ?? '',
                        options: [
                            { label: __('None', 'pcg'), value: '' },
                            { label: __('Wide', 'pcg'), value: 'wide' },
                            { label: __('Full', 'pcg'), value: 'full' }
                        ],
                        onChange: (val) => setAttributes({ align: val })
                    })
                )
            ),
            el('p', {}, __('Product Category Grid (renders on front-end).', 'pcg'))
        );
    },

    save() {
        return null;
    }
});
